drop database if exists 202project;
create database 202project;
use 202project;

-- 创建全体校内同学的表（用来核对注册用户是否是校内同学）
create table `legal_student_set` (
    `id` int not null,
    `name` varchar(64) not null,
    primary key (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 创建管理员表(网址管理员)
create table `admins` (
    `id` int not null,
    `name` varchar(64) not null,
    primary key (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 当前的用户的表
create table `users` (
    `id` int not null,
    `name` varchar(64) not null,
    `pwd` varchar(64) not null,
    `gender` varchar(8) default null,
    `phone` varchar(20) default null,
    `email` varchar(64) default null,
    `avatar` varchar(100) default null,
    `nickname` varchar(64) default null,
    primary key (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 预约表
CREATE TABLE `202project`.`Appointments` (
    `apNo` int not null auto_increment,
    `aptime` varchar(64) not null,
    `place` varchar(64) not null,
    `Reservation` int not null,
    primary key (`apNo`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 主页上的计划表
CREATE TABLE `202project`.`plan_table` (
    `plan` varchar(100) not null
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 添加原始数据

-- 添加到legal_student_set表
insert into legal_student_set values (1823482, 'Keyao.Huang');
insert into legal_student_set values (1823811, 'Kai.Chen');
insert into legal_student_set values (1812345, 'Bendan.Li');
-- 添加到admins表
insert into admins values (1823482, 'Keyao.Huang');
insert into admins values (1823811, 'Kai.Chen');
-- 添加到users表
insert into users(id, name, pwd) values (1823482, 'Keyao.Huang','1823482');
insert into users(id, name, pwd) values (1823811, 'Kai.Chen','1823811');
-- 添加信息到预约表
INSERT INTO `202project`.`appointments` (`aptime`, `place`, `Reservation`) VALUES ('20:00', 'bs', '5');
INSERT INTO `202project`.`appointments` (`aptime`, `place`, `Reservation`) VALUES ('10:00', 'cb', '2');
-- 添加信息到计划表
insert into plan_table values ('Wireframe prepare for new design');
insert into plan_table values ('UI perfection testing for Mega Section');
insert into plan_table values ('Finish PBI 3');
insert into plan_table values ('Prepare for the presentation');